# MINITRAIN

## Introduction

Minitrain: infographie

## Description général du Projet

- Voir des anciennes photos minitrains

- catégorie selon véhicules

- fonction recherche

- forum pour les anciens passionés

## Public Cible

- Ancien clients et passionnés de modélisme
- Tout âges
- Banlieue Rouennaise

## Définitions des besoins

| Problèmes       | Solutions          |
| --------------- | ------------------ |
| Plus de magasin | rappeler souvenirs |

## Sites de références

- https://www.breizh-modelisme.com/

## Fonctionnalités

### MVP (Minimal Viable Product)

- [] Naviguer par catégories
- [] Pouvoir échanger (forum)
- []
- []
- []
- []

### Evolutions potentielles

- [ ]
- [ ]
- [ ]
- [ ]

## Liste des technologies

### Front: HTML CSS Javascript

### Back : PHP Javascript

## APIs : AUCUN

## Navigateur compatibles?

## Abrborescence de l'application
